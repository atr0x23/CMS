-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 12, 2020 at 12:49 AM
-- Server version: 5.7.30
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atr0x_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins_online`
--

CREATE TABLE `admins_online` (
  `id` int(11) NOT NULL,
  `session` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins_online`
--

INSERT INTO `admins_online` (`id`, `session`, `time`) VALUES
(277, 'm7qidsadd4nt2dru8ngvnhcovq', 1589226879),
(278, 'dv1tkuopqfvn2g09s68jok2utv', 1589225989),
(279, 'ivcikvldbsn3stj5o1m1j8t9e7', 1590088759),
(280, 'rcoa7mh7rdgirtc9qvdj7cb8v3', 1591559930),
(281, '43ec7fd7ede027dccb6893809fa24a98', 1591123959),
(282, '913e1f39bac8b6cfa0cb3d9a4e02e930', 1591168572),
(283, '7a66832225b3b7625e41655c5255d067', 1591912156),
(284, 'bd2ff8fa7ff8a4badf1919fd0d745c45', 1591912157);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(3) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Bootstrap'),
(2, 'Javascript'),
(3, 'php5'),
(4, 'Java'),
(5, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(3) NOT NULL,
  `comment_post_id` int(3) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(255) NOT NULL,
  `comment_date` date NOT NULL,
  `comment_time` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_post_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`, `comment_time`) VALUES
(138, 40, 'Enas', 'enas@kati.gr', 'lalallalallaa', 'unapproved', '2020-05-17', '20:22:34 pm'),
(141, 42, 'Enas', 'enas@kati.gr', 'just a comment', 'approved', '2020-05-17', '20:55:30 pm'),
(143, 40, 'paparidis', 'test@test.gr', 'comment number 2 for the above post.  !!!!!!', 'unapproved', '2020-05-17', '21:05:48 pm'),
(144, 43, 'trelas', 'trelas@kati.gr', 'to prwto comment giauto to post!!!', 'approved', '2020-05-17', '21:08:19 pm'),
(145, 42, 'Enas allos', 'bla@vla.gr', 'just another comment for this post.!', 'approved', '2020-05-18', '12:13:23 pm'),
(146, 40, 'Enas', 'enas@kati.gr', 'another comment. Just that.', 'approved', '2020-05-18', '14:29:57 pm'),
(147, 58, 'Enas', 'enas@kati.gr', 'hahaha... eeerrimi!!! akou vlepwmpala?!!!!! :P', 'approved', '2020-05-18', '14:30:49 pm'),
(148, 62, 'Enas', 'enas@kati.gr', 'ore,  hamos stin vouli!!! poreia diamarturias COVID-19', 'approved', '2020-05-21', '20:10:07 pm'),
(149, 62, 'Enas allos', 'enas@kati.gr', 'lalalalallaalla', 'approved', '2020-05-21', '21:57:18 pm'),
(150, 63, 'kapoios', 'kapoios@kati.gr', 'lalala, allo ena comment, just for testing !!!', 'approved', '2020-06-12', '0:26:54 am'),
(151, 64, 'kapoios', 'kapoios@kati.gr', 'test comment!', 'unapproved', '2020-06-12', '0:35:47 am');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(3) NOT NULL,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_user` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  `post_views_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_category_id`, `post_title`, `post_user`, `post_date`, `post_image`, `post_content`, `post_tags`, `post_status`, `post_views_count`) VALUES
(40, 3, 'Just another post', 'hahas', '2020-06-11', '0-02-0a-0e8090cbdbfc6397de5fd9068293678088b44ceced336b0d204dd39312d15400_85d1b81c.jpg', '<p>asfdasdf asdfdas fasd fa fasf asdf a.asfdasdf asdfdas fasd fa fasf asdf a. asfdasdf asdfdas fasd fa fasf asdf a. asfdasdf asdfdas fasd fa fasf asdf a. asfdasdf asdfdas fasd fa fasf asdf a.</p>', 'php', 'published', 26),
(41, 1, 'Post No.1', 'demo', '2020-05-17', '0-02-0a-018f991712fbdc2d88cdd20a7b9d2f91dcb2a59730ffad6d47ad257d23cd8538_ba0bfe0b.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'bootstrap', 'published', 2),
(42, 2, 'Post No.2', 'demo', '2020-05-17', '0-02-0a-2f68f72f9b4cfc1e56424be4e99332ae38d9dcba62fa34ed58bdb17511b8da60_80f42ece.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'javascript', 'published', 18),
(43, 3, 'Post No.3', 'demo', '2020-05-17', '0-02-0a-1d583fef34245941da8e5b33c3438310e3a311e78bad6cd913ba916d1fd92967_8ccfe307.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'php', 'published', 4),
(44, 4, 'Post No.4', 'hahas', '2020-05-17', '0-02-0a-7cbc42b991fb3146f86bae666f14004b61ec4e18d3fad086d02a8dff57cf9b3d_b629b831.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'java', 'published', 0),
(45, 3, 'Post No.5', 'hahas', '2020-05-17', '0-02-0a-16260c2c91c74a0f9b0841a00a91e622fe16c75d094ef855b3748042ec1fa4a6_2f3ee46c.jpg', '<p>asfdasdf asdfdas fasd fa fasf asdf a.</p>', 'php', 'published', 0),
(46, 3, 'Post No.6', 'hahas', '2020-05-18', '0-02-0a-65240c119934c7cd783e9f1f732c52d8fe0c48b94a4ddcd7687ce9fb666922f6_613330d.jpg', '<p>asfdasdf asdfdas fasd fa fasf asdf a.</p>', 'php', 'published', 0),
(47, 4, 'Post No.7', 'hahas', '2020-05-18', '0-02-0a-2dae36377d79b5453492a12f5ff3ed49863053c7fe0d168ef2ea1e254404e007_243b86bf.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'java', 'published', 0),
(48, 3, 'Post No.8', 'demo', '2020-05-18', '0-02-0a-cb117de76256c58ac594efec101e33046948a967f2729dd6216272ebba27a47b_3718fc61.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'php', 'published', 0),
(49, 2, 'Post No.9', 'demo', '2020-05-18', '0-02-04-8c98346d43a4f24b97fedcf23d7772e1b0f6b17329aa1ac37df357f9f69b3086_full.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'javascript', 'published', 0),
(50, 1, 'Post No.10', 'demo', '2020-05-18', '0-02-0a-c8312e1cdb7b068d7ce424061c3579d57a535d7009f69049570888366a5d7175_b8541378.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'bootstrap', 'published', 0),
(51, 3, 'Post No.11', 'hahas', '2020-05-18', '0-02-04-f20af3e67c8e19542872fbb581906b9f2e98360e6ea1f0d44d4605f1c7c06abb_aabfcb6c.jpg', '<p>asfdasdf asdfdas fasd fa fasf asdf a.</p>', 'php', 'published', 0),
(52, 3, 'Post No.12', 'hahas', '2020-05-18', '0-02-0a-2fd6985b95ddddbe48ce8a8b615d490f67d9f076699175587d0f59d218ca0a1e_ff724117.jpg', '<p>asfdasdf asdfdas fasd fa fasf asdf a.</p>', 'php', 'published', 0),
(53, 1, 'Post No.13', 'demo', '2020-05-18', '0-02-0a-6aca79e26ee584e838b72381008d8175e34e5d9f9c5a64759db4b6b41f5c49ed_8e9dd82d.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'bootstrap', 'draft', 0),
(54, 2, 'Post No.14', 'demo', '2020-06-02', '0-02-0a-ddb6e3c71bcbd3228c401e3e865d42edd10d6b8bf3da86eeacd3a790cf8d8779_90f26bf7.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'javascript', 'published', 4),
(55, 3, 'Post No.15', 'demo', '2020-05-18', '0-02-0a-3aacd0df335d8d9cfb7832ae9a5694f05d5f2d6f2cb3f5ee6fb3d0873bccafaf_d70296be.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'php', 'draft', 0),
(56, 4, 'Post No.16', 'hahas', '2020-05-18', '0-02-04-7d714fc404ced8f91a6c58b75f42fd7890ce1c76b5313d1bc8786f71936722b0_e81fcb2f.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'java', 'published', 0),
(57, 3, 'Post No.17', 'hahas', '2020-05-18', '0-02-05-c76993acd123c69ceb2976ef6ec3135d5ade83745da146638d93f25d9bf3427f_6518b56a.jpg', '<p>asfdasdf asdfdas fasd fa fasf asdf a.</p>', 'php', 'draft', 5),
(58, 3, 'Post No.18', 'hahas', '2020-05-18', '0-02-0a-02b051f471ab31670c3c7747137b7eab4aceea2aff79577c7fa226491f33096a_e2cfa002.jpg', '<p>asfdasdf asdfdas fasd fa fasf asdf a.</p>', 'php', 'published', 2),
(59, 4, 'Post No.19', 'hahas', '2020-06-02', '0-02-0a-8074d678c6014adeb6789d03bb55165d3724ec8900dd4a75442f8d40dcaa7e3e_d83c31a3.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'java', 'published', 2),
(60, 3, 'Post No.20', 'demo', '2020-05-18', '0-02-04-0e3d7fac5a612565cccb2de8f71a8b098b4afeaf1e458c9c188d103161fe36da_7847d64.jpg', '<p>t has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'php', 'published', 0),
(62, 4, 'Post No.21', 'hahas', '2020-06-11', '0-02-04-bad45c9ce818114457938e40da6730756e4304da21f75647a432bd370bc24f2f_full.jpg', '<p>blah blah blah blah blah<strong> blah</strong> blah blah blahblah blah blah blah blah blahblah blah blah blah blah blah blah blah blah blah blah blah</p><p>&nbsp;</p>', 'java', 'published', 18),
(63, 1, 'Post No.22', 'hahas', '2020-06-12', '0-02-05-01524facb32d66fe3bcf04fbb6b63de85e1988f40f70f6548cf854b618ae8b53_b0e63c43.jpg', '<p>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</p>', 'bootstrap', 'published', 9),
(64, 4, 'Post No.23', 'user5', '2020-06-12', '0-02-04-6cbcde746c54bbcdadc8a63f3503b88bf5a4e01d982bf3439bcdac2c5c8715cb_77e0fb08.jpg', '<p>ÎœÎµ Ï„Î¿Î½ ÏŒÏÎ¿ <strong>Lorem ipsum</strong> Î±Î½Î±Ï†Î­ÏÎ¿Î½Ï„Î±Î¹ Ï„Î± ÎºÎµÎ¯Î¼ÎµÎ½Î± ÎµÎºÎµÎ¯Î½Î± Ï„Î± Î¿Ï€Î¿Î¯Î± ÎµÎ¯Î½Î±Î¹ Î±ÎºÎ±Ï„Î¬Î»Î·Ï€Ï„Î±, Î´ÎµÎ½ Î¼Ï€Î¿ÏÎµÎ¯ Î´Î·Î»Î±Î´Î® ÎºÎ¬Ï€Î¿Î¹Î¿Ï‚ Î½Î± Î²Î³Î¬Î»ÎµÎ¹ ÎºÎ¬Ï€Î¿Î¹Î¿ Î»Î¿Î³Î¹ÎºÏŒ Î½ÏŒÎ·Î¼Î± Î±Ï€ÏŒ Î±Ï…Ï„Î¬, ÎºÎ±Î¹ Î­Ï‡Î¿Ï…Î½ Î´Î·Î¼Î¹Î¿Ï…ÏÎ³Î·Î¸ÎµÎ¯ Î¼Îµ ÏƒÎºÎ¿Ï€ÏŒ Î½Î± Ï€Î±ÏÎ¿Ï…ÏƒÎ¹Î¬ÏƒÎ¿Ï…Î½ ÏƒÏ„Î¿Î½ Î±Î½Î±Î³Î½ÏŽÏƒÏ„Î· Î¼ÏŒÎ½Î¿ Ï„Î± Î³ÏÎ±Ï†Î¹ÏƒÏ„Î¹ÎºÎ¬ Ï‡Î±ÏÎ±ÎºÏ„Î·ÏÎ¹ÏƒÏ„Î¹ÎºÎ¬, Î±Ï…Ï„Î¬ ÎºÎ±Î¸\' ÎµÎ±Ï…Ï„Î¬, ÎµÎ½ÏŒÏ‚ ÎºÎµÎ¹Î¼Î­Î½Î¿Ï… (Ï€.Ï‡. <a href=\"https://el.wikipedia.org/wiki/%CE%93%CF%81%CE%B1%CE%BC%CE%BC%CE%B1%CF%84%CE%BF%CF%83%CE%B5%CE%B9%CF%81%CE%AC\">Î³ÏÎ±Î¼Î¼Î±Ï„Î¿ÏƒÎµÎ¹ÏÎ¬</a>, Î¼Î­Î³ÎµÎ¸Î¿Ï‚ ÎºÎ±Î¹ Ï‡ÏÏŽÎ¼Î± Î³ÏÎ±Î¼Î¼Î¬Ï„Ï‰Î½) Î® Î¼Î¹Î±Ï‚ Î¿Ï€Ï„Î¹ÎºÎ®Ï‚ Ï€Î±ÏÎ¿Ï…ÏƒÎ¯Î±ÏƒÎ·Ï‚ ÎºÎ±Î¹ ÏŒÏ‡Î¹ Î½Î± ÎµÎºÏ†Î­ÏÎ¿Ï…Î½ Î³ÏÎ±Ï€Ï„ÏŒ Î»ÏŒÎ³Î¿. Î¤Î± ÎºÎµÎ¯Î¼ÎµÎ½Î± Î±Ï…Ï„Î¬ Î±ÏÏ‡Î¯Î¶Î¿Ï…Î½ ÏƒÏ…Î½Î®Î¸Ï‰Ï‚ Î¼Îµ Ï„Î¿Î½ ÏŒÏÎ¿ Î±Ï…Ï„ÏŒ ÎºÎ±Î¹ Ï‡ÏÎ·ÏƒÎ¹Î¼Î¿Ï€Î¿Î¹Î¿ÏÎ½Ï„Î±Î¹ Ï€Î¿Î»Ï ÏƒÏ…Ï‡Î½Î¬ ÏƒÏ„Î· Î³ÏÎ±Ï†Î¹ÏƒÏ„Î¹ÎºÎ®. Î‘Ï€Î±ÏÏ„Î¯Î¶Î¿Î½Ï„Î±Î¹ ÏƒÏ…Î½Î®Î¸Ï‰Ï‚ Î±Ï€ÏŒ <a href=\"https://el.wikipedia.org/wiki/%CE%9B%CE%B1%CF%84%CE%B9%CE%BD%CE%B9%CE%BA%CE%AE_%CE%B3%CE%BB%CF%8E%CF%83%CF%83%CE%B1\">Î»Î±Ï„Î¹Î½Î¹ÎºÎ­Ï‚</a> Î»Î­Î¾ÎµÎ¹Ï‚ Î® Î»Î­Î¾ÎµÎ¹Ï‚ Ï€Î¿Ï… Î¼Î¿Î¹Î¬Î¶Î¿Ï…Î½ Î¼Îµ Î»Î±Ï„Î¹Î½Î¹ÎºÎ­Ï‚, Ï‡Ï‰ÏÎ¯Ï‚ ÏŒÎ¼Ï‰Ï‚ Î½Î± Î±Ï€Î¿ÎºÎ»ÎµÎ¯Î¿Î½Ï„Î±Î¹ ÎºÎ±Î¹ ÎºÎµÎ¯Î¼ÎµÎ½Î± Î¼Îµ Î»Î­Î¾ÎµÎ¹Ï‚ Î¬Î»Î»Ï‰Î½ Î³Î»Ï‰ÏƒÏƒÏŽÎ½. ÎŸ Î»ÏŒÎ³Î¿Ï‚ Ï€Î¿Ï… ÎµÏ€Î¹Î»Î­Î³Î¿Î½Ï„Î±Î¹ ÎºÎµÎ¯Î¼ÎµÎ½Î± Î±ÎºÎ±Ï„Î¬Î»Î·Ï€Ï„Î± ÎºÎ±Î¹ ÏŒÏ‡Î¹ Î±Ï€Î¿ÏƒÏ€Î¬ÏƒÎ¼Î±Ï„Î± ÎºÎµÎ¹Î¼Î­Î½Ï‰Î½ Ï€Î¿Ï… Î½Î± ÎµÎ¼Ï€ÎµÏÎ¹Î­Ï‡Î¿Ï…Î½ ÎºÎ¬Ï€Î¿Î¹Î¿ Î½ÏŒÎ·Î¼Î± ÎµÎ¯Î½Î±Î¹ Î³Î¹Î± Î½Î± Î´Î¿Î¸ÎµÎ¯ Î­Î¼Ï†Î±ÏƒÎ· ÏƒÏ„Î± Î³ÏÎ±Ï†Î¹ÏƒÏ„Î¹ÎºÎ¬ Ï‡Î±ÏÎ±ÎºÏ„Î·ÏÎ¹ÏƒÏ„Î¹ÎºÎ¬ ÎµÎ½ÏŒÏ‚ ÎºÎµÎ¹Î¼Î­Î½Î¿Ï… ÎºÎ±Î¹ ÏƒÏ„Î· ÏƒÎµÎ»Î¹Î´Î¿Ï€Î¿Î¯Î·ÏƒÎ® Ï„Î¿Ï… Ï€ÏÎ¿ÎºÎµÎ¹Î¼Î­Î½Î¿Ï… Î½Î± Î³Î¯Î½ÎµÎ¹ Î· ÎµÏ€Î¹Î»Î¿Î³Î® Ï„Î¿Ï…Ï‚, Ï‡Ï‰ÏÎ¯Ï‚ Î½Î± Î±Ï€Î¿ÏƒÏ€Î¬Ï„Î±Î¹ Î· Ï€ÏÎ¿ÏƒÎ¿Ï‡Î® Ï„Î¿Ï… Î±Î½Î±Î³Î½ÏŽÏƒÏ„Î· Î±Ï€ÏŒ Ï„Î· Î³Î»ÏŽÏƒÏƒÎ±, Ï„Î¿ ÏÏ†Î¿Ï‚, Ï„Î· ÏƒÏÎ½Ï„Î±Î¾Î· Î® Ï„Î¿ Ï€ÎµÏÎ¹ÎµÏ‡ÏŒÎ¼ÎµÎ½Î¿ ÎµÎ½ÏŒÏ‚ ÎºÎ±Ï„Î±Î»Î·Ï€Ï„Î¿Ï ÎºÎµÎ¹Î¼Î­Î½Î¿Ï…</p>', 'java, js', 'published', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(3) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `user_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`, `user_date`) VALUES
(35, 'demo', '$2y$10$poustiagiacryptografie1bvdIVcsnlLh36Q94BwkVBI/ZMDP4NG', 'admin', 'administrator', 'demo@in.gr', '0-02-0a-57a2bf5eb554c4d1a6afaeed8b693429439f06f7dfd74c3ce24670e139a8f337_1b8ccc12.jpg', 'administrator', '2020-05-01'),
(39, 'hahas', '$2y$10$HEpmzUOjwHaxVqTNnNhOJu8aZ6CGDEm0xahd1MPF7AcQCCUExK4r2', 'hahas', 'hahanoulis', 'hahas@kati.com', 'media-share-0-02-05-a258f328d10710072cd3e6c2dd4d006153c8c790a40d76cdf5370960b0133b4c-65976789-7a66-4a0f-975b-c6b438daefe6.jpg', 'administrator', '2020-05-07'),
(40, 'user1', '$2y$12$GF9rL.JFSkLAwQ5NNRPYrOG3jzjlZDqZECNL9Ah78iXG/uhlQ16R.', 'user', 'kati', 'user@gmail.com', 'media-share-0-02-05-3c59abba834a4ed0dcd4f469c864a111c5beabd245e11d277d7da5a6cc88861e-95e46930-e566-4478-8b4e-4903d4878f52.jpg', 'subscriber', '2020-05-03'),
(41, 'user2', '$2y$12$tw8NJ7If/bE7IIPEsE99U.6JDsI8QKQbPhNcSu9sNbze7BHRnDe/q', 'user', 'useridis', 'user2@gmail.com', 'media-share-0-02-05-780a3488659133cd5d293adbbf97f94b56bd2cf39b6fbdb41ff576e20c193003-4abe5b89-fedb-4d9a-a8fc-26c396df0639.jpg', 'subscriber', '2020-05-10'),
(42, 'user3', '$2y$10$462oavCvFTJyORCe55D1beLegQsU3ZP00nmGhmdNl6sNP2u5AvHUe', 'userios', 'userakos', 'user3@gmail.com', '0-02-0a-5f19322ddc9bbf17fa2747ab4c4fe6e455623b7aae3f9cf8779f509a22d23fc9_66e4d70f.jpg', 'subscriber', '2020-05-18'),
(43, 'user4', '$2y$10$JyOMnKsu9vMLGEzfJH3yQeNJIEvIOOAMefSfWQkWO9WZBXawX2rVG', 'user', 'userinos', 'user4@gmail.com', '0-02-0a-726c21faa445bba1cf1979d81cd854e4b52f74776f1179900a224cec0a82187d_c1d7ae68.jpg', 'subscriber', '2020-05-18'),
(44, 'user5', '$2y$10$2Knk3zjuCjHLwQQTcmGA0.N.CZFTHIzJDJDhpmeoBKnBiMOV2rc3K', 'enaname', 'enalastname', 'user5@gmail.com', '0-02-0a-3e06c4a3affc8644f34dbc2eb31900b32756b0d6bb639caebca904d5f119e204_96fbaeaa.jpg', 'administrator', '2020-06-11');

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--

CREATE TABLE `users_online` (
  `id` int(11) NOT NULL,
  `session` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_online`
--

INSERT INTO `users_online` (`id`, `session`, `time`) VALUES
(7, 'm7qidsadd4nt2dru8ngvnhcovq', 1589268550),
(8, 'dv1tkuopqfvn2g09s68jok2utv', 1589968495),
(9, 'oklnsdbm0ba6tjb449kejt367f', 1589228147),
(10, '1s327j1t43se65mg366fghaurr', 1589228045),
(11, '2rd6o26uml14af0tombkjgvls9', 1589228046),
(12, 'p30s765v5q4jbrkr0fst69fp8d', 1589228048),
(13, 'vojcdlcda7r4bi62jj3s51s4hl', 1589273312),
(14, '56d4mu1v6dfjlufq84055emmrr', 1589268568),
(15, 'ivcikvldbsn3stj5o1m1j8t9e7', 1590138639),
(16, 'honvak7iq4o5slbg7gn5r5fkcq', 1589741820),
(17, 'rsdkf99hq5g58bq5b5el3pa9i5', 1589741821),
(18, '0tj30k1ptabtpcl5u58hgvqj76', 1589741823),
(19, 'oqbduqk74vuo64t1u2769g7do1', 1590085012),
(20, 'l8br7bq16vlhd34h8dng44mg85', 1590085013),
(21, 'o207bmhah4bp6per1a2c4u6ril', 1590085014),
(22, 'svllnkt2v55qqkfigk29qu05pg', 1590087411),
(23, 'bohq1l143950iipe5ium2hi2hc', 1590087412),
(24, 'opa09jfkp6q9ea2gqf2fi6kh3f', 1590087414),
(25, 'rcoa7mh7rdgirtc9qvdj7cb8v3', 1591770269),
(26, 'cdjsc4khtih557ea8p149n4fc5', 1591122714),
(27, '43ec7fd7ede027dccb6893809fa24a98', 1591123881),
(28, '913e1f39bac8b6cfa0cb3d9a4e02e930', 1591168579),
(29, '9d956c5fc146c8cef5e3772e0cbf1e53', 1591560136),
(30, '7a66832225b3b7625e41655c5255d067', 1591912156),
(31, 'bd2ff8fa7ff8a4badf1919fd0d745c45', 1591902492);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins_online`
--
ALTER TABLE `admins_online`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users_online`
--
ALTER TABLE `users_online`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins_online`
--
ALTER TABLE `admins_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=285;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users_online`
--
ALTER TABLE `users_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
